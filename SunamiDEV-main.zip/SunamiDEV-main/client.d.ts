declare const Ultraviolet: typeof import('./uv').Ultraviolet;

declare var __uv$config: import('./uv').UVConfig;
